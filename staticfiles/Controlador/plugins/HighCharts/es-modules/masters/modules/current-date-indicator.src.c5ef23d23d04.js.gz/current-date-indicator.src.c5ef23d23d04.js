/**
 * @license Highcharts Gantt JS v10.1.0 (2022-04-29)
 * @module highcharts/modules/current-date-indicator
 * @requires highcharts
 *
 * CurrentDateIndicator
 *
 * (c) 2010-2021 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/CurrentDateIndication.js';
